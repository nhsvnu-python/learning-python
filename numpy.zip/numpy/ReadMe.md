# Sách hay Numpy

1. [Python for Data Analysis, 2nd Edition](http://file.allitebooks.com/20171009/Python%20for%20Data%20Analysis,%202nd%20Edition.pdf)

https://stackoverflow.com/questions/5020538/python-get-output-from-a-command-line-which-exits-with-nonzero-exit-code?noredirect=1&lq=1
