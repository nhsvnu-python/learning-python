import numpy as np

rands = np.random.randn(1000000)
print(min(rands), max(rands))