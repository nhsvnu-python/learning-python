import numpy as np
e = np.eye(4, dtype=int)
print(e)

b = np.identity(2, dtype=float)
print("Matrix b : \n", b)

a = np.identity(4, dtype=int)
print("\nMatrix a : \n", a)