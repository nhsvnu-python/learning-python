import numpy as np
d = np.arange(2, 9)
print(d)

d = np.arange(10, 45, 5)
print(d)

d = np.arange(0, 1, 0.1) # Tham số thứ 3 là bước nhảy
print(d)

d = np.arange(10, 1, -1) # Bước nhảy giật lùi
print(d)

d = np.linspace(0, 2, 11) # Tham số thứ 3 là số phần tử
print(d)
print(len(d))