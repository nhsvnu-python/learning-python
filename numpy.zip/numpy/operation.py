import numpy as np
a = np.array([20, 30, 40, 50])
b = np.arange(4)
print(b)

c = a-b
print(c)

print(b**2)

print(10 * np.sin(a))

print(a < 35)
