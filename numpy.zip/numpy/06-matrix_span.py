import numpy as np
a = np.arange(4).reshape(2, -1)
print(a)
a.span()
